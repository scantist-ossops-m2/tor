/* Added for Tor. */
#include "torint.h"
#define crypto_uint64 uint64_t
